// app.js
// 导入本地数据（备用，本例主要从云数据库读取）
// var jsonList = require('data/math.js');

wx.cloud.init({
  // 初始化云环境，填入你的环境 ID
  env: 'cloudbase-1gy0fi0b7ffbb9f1',
  traceUser: true
 })
 
 App({
  onLaunch() {
    // ===== 检查并初始化云能力 =====
    if (!wx.cloud) {
      console.error('请使用基础库 2.2.3 或以上版本以使用云能力');
    }
 
    // ===== 获取用户 openid =====
    wx.cloud.callFunction({
      name: 'login',
      success: res => {
        console.log('获取到用户 openid:', res.result.openid);
        this.globalData.openid = res.result.openid;
 
        // openid 获取成功后，可以加载用户个性化数据
        this.loadQuestionList();
      },
      fail: err => {
        console.error('获取 openid 失败:', err);
        // 即使 openid 获取失败，也尝试加载题库
        this.loadQuestionList();
      }
    });
  },
 
  // 从云数据库获取题库列表
  loadQuestionList() {
    const db = wx.cloud.database();
    const _ = db.command;
 
    db.collection('questions')        // 假设集合名为 questions
      .get()
      .then(res => {
        console.log('从云数据库读取题库数据:', res.data);
        this.globalData.questionList = res.data;
      })
      .catch(err => {
        console.error('读取题库失败，使用本地备份数据:', err);
        // 如果云端读取失败，可退回使用本地数据
        // this.globalData.questionList = jsonList;
      });
  },
 
  globalData: {
    openid: null,
    userInfo: null,
    questionList: []    // 存放从云数据库或本地加载的题库
  }
 });
 