// 云函数入口文件
const cloud = require('wx-server-sdk');

cloud.init({
  // env 参数指定环境 ID，这里标记为云函数运行时所在的环境
  // 在实际开发中，建议将此值替换为你的真实环境 ID
  env: cloud.DYNAMIC_CURRENT_ENV
});

// 获取云数据库引用
const db = cloud.database();
// 获取数据库操作符
const _ = db.command;

/**
 * 云函数：updateUserScore
 * 功能：更新或创建用户的累计答对题目数、昵称和头像
 *
 * @param {Object} event - 客户端调用云函数时传入的参数
 *   @param {number} correctCountIncrement - 本次答对的题目数量增量，默认为1
 *   @param {string} nickName - 用户昵称
 *   @param {string} avatarUrl - 用户头像URL
 * @param {Object} context - 云函数上下文
 */
exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext();
  const openid = wxContext.OPENID; // 获取当前用户的openid，这是用户的唯一标识

  const {
    correctCountIncrement = 1, // 默认每次答对题目数增加1
    nickName,
    avatarUrl
  } = event;

  // 检查传入的增量是否有效
  if (typeof correctCountIncrement !== 'number' || correctCountIncrement <= 0) {
    return {
      success: false,
      message: 'correctCountIncrement 必须是大于0的数字'
    };
  }

  try {
    // 尝试获取用户在 user_scores **中的记录
    // 我们使用openid作为文档的 _id，这样可以直接通过doc(openid)来查找和更新
    const userRecord = await db.collection('user_scores').doc(openid).get();

    if (userRecord.data) {
      // 用户记录已存在，执行更新操作
      await db.collection('user_scores').doc(openid).update({
        data: {
          totalCorrectCount: _.inc(correctCountIncrement), // 原子性递增操作
          nickName: nickName, // 每次更新时也更新昵称和头像，确保是最新的
          avatarUrl: avatarUrl,
          lastUpdate: new Date() // 记录最后更新时间
        }
      });
      console.log(`用户 ${openid} 成绩更新成功，增加 ${correctCountIncrement} 道题。`);
    } else {
      // 用户记录不存在，执行添加操作
      await db.collection('user_scores').add({
        data: {
          _id: openid, // 明确指定 _id 为 openid
          nickName: nickName,
          avatarUrl: avatarUrl,
          totalCorrectCount: correctCountIncrement, // 首次记录
          lastUpdate: new Date()
        }
      });
      console.log(`用户 ${openid} 新增记录成功，初始答对 ${correctCountIncrement} 道题。`);
    }

    return {
      success: true,
      openid: openid
    };

  } catch (e) {
    console.error('更新用户成绩失败', e);
    return {
      success: false,
      openid: openid,
      error: e
    };
  }
};
