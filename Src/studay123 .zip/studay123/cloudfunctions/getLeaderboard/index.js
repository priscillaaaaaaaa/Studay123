// 云函数入口文件
const cloud = require('wx-server-sdk');

cloud.init({
  env: cloud.DYNAMIC_CURRENT_ENV
});

const db = cloud.database();
const _ = db.command;

exports.main = async (event, context) => {
  const wxContext = cloud.getWXContext();
  const openid = wxContext.OPENID; // 获取当前用户的openid

  try {
    // 1. 查询排行榜前N名用户
    const topUsersRes = await db.collection('user_scores')
      .orderBy('totalCorrectCount', 'desc')
      .limit(20)
      .get();

    const topUsers = topUsersRes.data;

    // 2. 查询当前用户自己的信息和排名
    let currentUserRank = -1; // 默认值：未上榜
    let currentUserScore = 0; // 默认值：0分
    let currentUserInfo = {
      _id: openid,
      nickName: '匿名用户', // 默认昵称
      avatarUrl: '', // 默认头像
      totalCorrectCount: 0
    };

    const foundInTop = topUsers.find(user => user._id === openid);
    if (foundInTop) {
      // 用户在前N名中
      currentUserRank = topUsers.indexOf(foundInTop) + 1;
      currentUserScore = foundInTop.totalCorrectCount;
      currentUserInfo = foundInTop;
    } else {
      // 用户不在前N名中，需要单独查询其记录
      // 使用 try...catch 包裹，以防文档不存在
      try {
        const currentUserRecordRes = await db.collection('user_scores').doc(openid).get();
        
        if (currentUserRecordRes.data) {
          // 用户有记录
          currentUserInfo = currentUserRecordRes.data;
          currentUserScore = currentUserInfo.totalCorrectCount;

          // 计算当前用户的精确排名
          const higherScoresCountRes = await db.collection('user_scores')
            .where({
              totalCorrectCount: _.gt(currentUserScore)
            })
            .count();
          currentUserRank = higherScoresCountRes.total + 1;
        }
        // else: 如果 currentUserRecordRes.data 为空，说明用户没有记录，
        // currentUserInfo、currentUserRank、currentUserScore 会保持默认值，这是我们期望的行为。
      } catch (docError) {
        // 如果文档不存在 (document.get:fail document with _id ... does not exist)
        // 捕获这个错误，但不重新抛出，而是保持默认的未上榜状态
        console.warn(`当前用户 ${openid} 记录不存在，将显示为未上榜。`, docError.message);
        // currentUserInfo, currentUserRank, currentUserScore 保持默认值即可
      }
    }

    return {
      success: true,
      topUsers: topUsers,
      currentUser: currentUserInfo,
      currentUserRank: currentUserRank,
      currentUserScore: currentUserScore
    };

  } catch (e) {
    console.error('获取排行榜失败', e);
    return {
      success: false,
      message: '获取排行榜数据失败，请稍后再试。',
      errorDetail: e.message
    };
  }
};
