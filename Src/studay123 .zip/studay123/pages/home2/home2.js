// pages/home2/home2.js
Page({
  data: {

  },
  onLoad(options) {

  },
  
  gotoMhome: function() {
    wx.navigateTo({
      url: '/packageM/pages/mathhome/mathhome'
    });
  },
  gotoLboard: function() {
    wx.navigateTo({
      url: '/packageM/pages/leaderboard/leaderboard'
    });
  }
})