//logs.js
const util = require('../../utils/util.js')
Page({
  data: {
    logs: [],
    grade: ["一","二","三"]
  },
  onShow: function() { 
    wx.onThemeChange((result) => {
        this.setData({
          theme: result.theme
        })
      })
    this.setData({
      logs: this.formatLogs()
    })
  },
  // 拿到缓存并格式化日期数据
  formatLogs: function(){
    let newList = [];
    (wx.getStorageSync('logs') || []).forEach(log => {
      if(log.date){
        log['date'] = util.formatTime(new Date(log.date));
        newList.push(log);
      }
      log['testId'] =((log.testId=='math1')?"一":((log.testId=='math2')?"二":"三"))
    })
    return newList;
  }
})
