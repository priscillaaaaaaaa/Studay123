// pages/home4/home4.js
const app = getApp();
const defaultAvatarUrl = 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0';

Page({
  data: {
    nickname: '',                 // 用于界面显示（映射云端 nickName）
    name: '',                     // 如果你页面单独需要，可保留
    avatarUrl: defaultAvatarUrl,  // 用于界面显示（映射云端 avatarUrl）
    openid: '',
  },

  async onLoad() {
    // 1) 优先用缓存回显，避免白屏
    const cachedNickname = wx.getStorageSync('nickname');
    const cachedAvatar = wx.getStorageSync('avatarUrl');
    if (cachedNickname) this.setData({ nickname: cachedNickname });
    if (cachedAvatar) this.setData({ avatarUrl: cachedAvatar });

    // 2) 获取 openid（缓存没有则调云函数）
    let openid = wx.getStorageSync('openid');
    if (!openid) {
      try {
        const res = await wx.cloud.callFunction({ name: 'login', data: {} });
        openid = res?.result?.openid || '';
        if (openid) wx.setStorageSync('openid', openid);
      } catch (e) {
        console.error('获取 openid 失败：', e);
      }
    }
    this.setData({ openid });

    // 3) 读取云端 user_scores/{openid}，并用 nickName / avatarUrl 正确回显
    if (openid) {
      try {
        const db = wx.cloud.database();
        const userRes = await db.collection('user_scores').doc(openid).get();
        const cloudNick = userRes?.data?.nickName || '';     // ⚠️ 注意大小写：nickName
        const cloudAvatar = userRes?.data?.avatarUrl || '';  // avatarUrl

        // 用云端为准；没有就保持默认/缓存
        const finalNickname = cloudNick || this.data.nickname || '微信用户';
        const finalAvatar = cloudAvatar || this.data.avatarUrl || defaultAvatarUrl;

        this.setData({
          nickname: finalNickname,
          avatarUrl: finalAvatar,
        });

        // 顺便更新本地缓存，供其它页面使用
        wx.setStorageSync('nickname', finalNickname);
        wx.setStorageSync('avatarUrl', finalAvatar);
      } catch (err) {
        // 文档不存在或读取失败，保持现有显示即可
        console.warn('读取 user_scores 失败或不存在：', err);
      }
    }
  },

  // —— 以下是你原有的交互，可保留 —— //
  onChooseAvatar(e) {
    const { avatarUrl } = e.detail;
    console.log('chooseAvatar:', e);
    this.setData({ avatarUrl });
    wx.setStorageSync('avatarUrl', avatarUrl);
  },

  inputChange(e) {
    const { name } = e.detail;
    console.log('name:', e);
    this.setData({ name });
  },

  redirectToLogs() {
    wx.navigateTo({ url: '/pages/logs/logs' });
  },

  tointro() {
    wx.navigateTo({ url: '/pages/intro/intro' });
  },

  tosetting() {
    wx.navigateTo({ url: '/pages/setting/setting' });
  },
});
