// index.js
const app = getApp();
const defaultAvatarUrl = 'https://mmbiz.qpic.cn/mmbiz/icTdbqWNOwNRna42FI242Lcia07jQodd2FJGIYQfG0LAJGFxM4FbnQP6yfMxBgJ0F3YRqJCJ1aPAK2dQagdusBZg/0';

// 你的项目里云端有时会存 "微信用户" 这种占位，所以也把它视为“不完整”
const PLACEHOLDER_NICKNAMES = ['微信用户', '']; 

Page({
  data: {
    userInfo: {},
    hasUserInfo: false,
    avatarUrl: defaultAvatarUrl,
    nickname: '',
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    openid: '',
    userExistsInCloud: false,
  },

  onLoad() {
    this.getOpenIdAndUserInfo();
  },

  onShow() {
    // 回显本地
    const storedAvatarUrl = wx.getStorageSync('avatarUrl');
    const storedNickname = wx.getStorageSync('nickname');
    if (storedAvatarUrl && this.data.avatarUrl !== storedAvatarUrl) {
      this.setData({ avatarUrl: storedAvatarUrl });
    }
    if (storedNickname && this.data.nickname !== storedNickname) {
      this.setData({ nickname: storedNickname });
    }
  },

  // 获取 openid + 从云端判断是否“真的完善过”
  async getOpenIdAndUserInfo() {
    wx.showLoading({ title: '加载中...' });
    try {
      // 1. 先拿 openid
      const res = await wx.cloud.callFunction({
        name: 'login',
        data: {},
      });
      const openid = res && res.result && res.result.openid;
      if (!openid) throw new Error('未获取到 openid');

      this.setData({ openid });
      wx.setStorageSync('openid', openid);

      // 2. 去云端看这个人有没有资料
      const db = wx.cloud.database();
      let userRes = null;
      try {
        userRes = await db.collection('user_scores').doc(openid).get();
      } catch (err) {
        // 文档不存在会到这里
        userRes = null;
      }

      // 3. 判断云端资料是否“完善”
      if (userRes && userRes.data) {
        const { nickName, avatarUrl } = userRes.data;

        const cloudNickname = nickName || '';
        const cloudAvatar = avatarUrl || '';

        const nicknameIsPlaceholder = PLACEHOLDER_NICKNAMES.includes(cloudNickname);
        const avatarIsDefault = !cloudAvatar || cloudAvatar === defaultAvatarUrl;

        // ✅ 只有“头像不是默认 && 昵称不是占位”才算真正完善过，可以直接跳
        if (!nicknameIsPlaceholder && !avatarIsDefault) {
          // 云端资料完整 → 直接进首页
          this.setData({
            avatarUrl: cloudAvatar,
            nickname: cloudNickname,
            hasUserInfo: true,
            userExistsInCloud: true,
          });
          wx.setStorageSync('avatarUrl', cloudAvatar);
          wx.setStorageSync('nickname', cloudNickname);

          wx.hideLoading();
          wx.switchTab({ url: '/pages/home2/home2' });
          return;
        } else {
          // 云端有记录，但只是占位，不能跳，要停在当前页让用户改
          this.setData({
            avatarUrl: cloudAvatar || defaultAvatarUrl,
            nickname: !nicknameIsPlaceholder ? cloudNickname : '',
            hasUserInfo: false,
            userExistsInCloud: true,
          });
          // 不跳
          wx.hideLoading();
          return;
        }
      }

      // 4. 云端也没有 → 新用户，停在登录页
      const storedAvatarUrl = wx.getStorageSync('avatarUrl');
      const storedNickname = wx.getStorageSync('nickname');
      if (storedAvatarUrl) this.setData({ avatarUrl: storedAvatarUrl });
      if (storedNickname) this.setData({ nickname: storedNickname });
      this.setData({ userExistsInCloud: false, hasUserInfo: false });
      wx.hideLoading();
    } catch (err) {
      console.error('获取 OpenID 或用户信息失败', err);
      wx.hideLoading();
      wx.showToast({
        title: '登录失败，请重试',
        icon: 'none'
      });
    }
  },

  // 选择头像
  onChooseAvatar(e) {
    const { avatarUrl } = e.detail;
    this.setData({
      avatarUrl,
      hasUserInfo: !!this.data.nickname
    });
    wx.setStorageSync('avatarUrl', avatarUrl);
    this.trySaveAndNavigate();
  },

  // 提交昵称
  formSubmit(e) {
    const nickname = (e.detail && e.detail.value && e.detail.value.nickname) || '';
    if (nickname.trim()) {
      wx.setStorageSync('nickname', nickname.trim());
      this.setData({
        nickname: nickname.trim(),
        hasUserInfo: !!this.data.avatarUrl
      });
      this.trySaveAndNavigate();
    } else {
      wx.showToast({
        title: '请输入昵称',
        icon: 'none'
      });
    }
  },

  // 保存到云端
  async updateUserInfoInCloud() {
    const { openid, avatarUrl, nickname } = this.data;
    if (!openid) {
      console.error('OpenID 未获取到，无法更新云数据库。');
      return false;
    }
    if (!avatarUrl || !nickname) {
      console.warn('头像或昵称不完整，暂不更新云数据库。');
      return false;
    }

    wx.showLoading({ title: '保存中...' });
    try {
      const db = wx.cloud.database();
      await db.collection('user_scores').doc(openid).set({
        data: {
          nickName: nickname,
          avatarUrl: avatarUrl,
          totalCorrectCount: 0,
          lastUpdateTime: db.serverDate(),
        }
      });
      wx.hideLoading();
      return true;
    } catch (err) {
      console.error('保存用户信息到云数据库失败', err);
      wx.hideLoading();
      wx.showToast({
        title: '保存信息失败',
        icon: 'none'
      });
      return false;
    }
  },

  // 头像+昵称齐了就保存并跳
  async trySaveAndNavigate() {
    const storedAvatarUrl = wx.getStorageSync('avatarUrl');
    const storedNickname = wx.getStorageSync('nickname');
    // 判断是否是默认或占位
    const isDefaultAvatar = !storedAvatarUrl || storedAvatarUrl === defaultAvatarUrl;
    const isPlaceholderName = !storedNickname || PLACEHOLDER_NICKNAMES.includes(storedNickname);

    if (!isDefaultAvatar && !isPlaceholderName) {
      const ok = await this.updateUserInfoInCloud();
      if (ok) {
        wx.switchTab({ url: '/pages/home2/home2' });
      }
    } else {
      let title = '';
      if (!storedAvatarUrl && !storedNickname) {
        title = '请选择头像并输入昵称';
      } else if (!storedAvatarUrl) {
        title = '请选择头像';
      } else if (!storedNickname) {
        title = '请输入昵称';
      }
      wx.showToast({ title, icon: 'none' });
    }
  },

  // 兼容原来的
  checkAndNavigate(e) {
    const isGuestMode = e && e.currentTarget && e.currentTarget.dataset && e.currentTarget.dataset.mode === 'guest';
    if (isGuestMode) {
      wx.switchTab({ url: '/pages/home2/home2' });
      return;
    }
    this.trySaveAndNavigate();
  },
});
