// pages/setting/setting.js
Page({
    onLoad(options) {

    },
    tointro: function() {
        wx.navigateTo({
          url: '/pages/intro/intro'
        });
      },
      clear:function(){
          wx.clearStorageSync();
          console.log(wx.getStorageInfoSync());
          wx.showToast({
            title: '已清空缓存',
            icon: 'none'
          });
      }
})