Page({
    data: {
        wrongques: []
    },
  
    onLoad: function() {
      this.loadwrongques();
    },
  
    // 加载错题列表
    loadwrongques: function() {
      const wrongques = wx.getStorageSync('wrongques') || [];
      this.setData({ wrongques });
    },
  
    // 删除错题
    deleteWord: function(event) {
      const index = event.currentTarget.dataset.index;
      const updatedFavorites = this.data.wrongques;
      updatedFavorites.splice(index, 1);
  
      // 更新数据并同步到本地存储
      this.setData({ wrongques: updatedFavorites });
      wx.setStorageSync('wrongques', updatedFavorites);
      wx.showToast({
        title: '已移出错题',
        icon: 'none'
      });
    }
  });
   