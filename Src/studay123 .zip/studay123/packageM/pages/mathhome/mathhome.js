// pages/mathhome/mathhome.js
Page({
  data: {
    pickerVisible: false, // 控制选择器模态框的显示隐藏
    // 'sel' 字段已移除，因为 multiArray[0] 已经包含了年级信息
    multiArray: [
      ['一年级', '二年级', '三年级'], // 年级选项
      ['5', '10', '20'] // 题目数量选项
    ],
    multiIndex: [0, 0], // 默认选中第一个年级和第一个题目数量
    testIds: ['math1', 'math2', 'math3'], // 与 multiArray[0] 对应的测试ID
    // 'selectedTestId' 字段已移除，会在 confirmSelection 中动态获取
  },

  onLoad: function() {
    // 页面加载时的初始化逻辑，如果需要
  },

  /**
   * 显示“做新题”的选择器模态框
   */
  showPicker: function() {
    this.setData({
      pickerVisible: true
    });
  },

  /**
   * 隐藏选择器模态框（点击取消按钮或点击蒙层时调用）
   */
  hidePicker: function() {
    this.setData({
      pickerVisible: false
    });
  },

  /**
   * 阻止事件冒泡，防止点击模态框内容时关闭模态框
   */
  stopProp: function() {
    // 这是一个空函数，用于在 WXML 中通过 catchtap 阻止事件冒泡
  },

  /**
   * 多列选择器值改变时触发
   * 仅更新 multiIndex，不进行页面跳转或关闭模态框
   */
  onMultiChange: function(e) {
    this.setData({
      multiIndex: e.detail.value
    });
  },

  /**
   * 确认选择后跳转到答题页面
   */
  confirmSelection: function() {
    const selectedGradeIndex = this.data.multiIndex[0];
    const selectedNumIndex = this.data.multiIndex[1];

    const selectedTestId = this.data.testIds[selectedGradeIndex]; // 根据年级索引获取对应的测试ID
    const selectedNum = this.data.multiArray[1][selectedNumIndex]; // 获取选择的题目数量

    console.log(`确认选择：年级ID ${selectedTestId}, 题目数量 ${selectedNum}`);

    // 跳转到答题页面，并传递选择的参数
    wx.navigateTo({
      url: `/packageM/pages/math1/math1?testId=${selectedTestId}&number=${selectedNum}`
    });

    this.hidePicker(); // 关闭模态框
  },

  /**
   * “错题重做”功能
   */
  redoWrongQuestions() {
    let wrongques = wx.getStorageSync('wrongques') || []; // 获取错题数据

    console.log('获取的错题数据:', wrongques);

    // 过滤出未做对的错题
    let wrongquesToRedo = wrongques.filter(item => !item.isCorrect);

    if (wrongquesToRedo.length > 0) {
      // 如果有错题，跳转到重做页面并传递错题数据
      wx.navigateTo({
        url: '/packageM/pages/wrongQuestionsRedo/wrongQuestionsRedo', // 假设重做页面路径
        success: function(res) {
          // 使用 EventChannel 传递数据，确保数据量大时也能稳定传递
          res.eventChannel.emit('acceptWrongQuestions', {
            wrongques: wrongquesToRedo
          });
        }
      });
    } else {
      wx.showToast({
        title: '恭喜！您已经全部掌握啦，去做些新练习吧！',
        icon: 'none'
      });
    }
  },

  /**
   * 跳转到“收藏”页面
   */
  goToPage2: function() {
    wx.navigateTo({
      url: '/packageM/pages/fav/fav' // 收藏页面路径
    });
  },

  /**
   * 跳转到“错题”列表页面
   */
  goToPage3: function() {
    wx.navigateTo({
      url: '/packageM/pages/wrong/wrong' // 错题列表页面路径
    });
  },
  /**
   * 跳转到“学习”列表页面
   */
  goToHome2: function() {
    wx.switchTab({
      url: '/pages/home2/home2' // 学习主页页面路径
    });
  }
});
