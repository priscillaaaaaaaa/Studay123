// pages/leaderboard/leaderboard.js
const app = getApp();

Page({
  data: {
    leaderboardList: [], // 排行榜数据
    myRank: -1,          // 我的排名
    myScore: 0,          // 我的分数
    myInfo: null,        // 我的详细信息 (昵称、头像等)
    loading: true,       // 加载状态
    error: false,        // 错误状态
    errorMessage: ''     // 错误信息
  },

  onLoad: function() {
    this.getLeaderboardData();
  },

  onPullDownRefresh: function() {
    // 下拉刷新时重新获取数据
    this.getLeaderboardData(true);
  },

  getLeaderboardData: async function(isRefresh = false) {
    if (!isRefresh) {
      this.setData({ loading: true, error: false, errorMessage: '' });
    }

    try {
      const res = await wx.cloud.callFunction({
        name: 'getLeaderboard',
        data: {}
      });

      console.log('排行榜数据:', res.result);

      if (res.result && res.result.success) {
        this.setData({
          leaderboardList: res.result.topUsers,
          myRank: res.result.currentUserRank,
          myScore: res.result.currentUserScore,
          myInfo: res.result.currentUser,
          loading: false,
          error: false
        });
      } else {
        this.setData({
          loading: false,
          error: true,
          errorMessage: res.result ? res.result.message : '未知错误'
        });
        wx.showToast({ title: res.result ? res.result.message : '加载失败', icon: 'none' });
      }
    } catch (err) {
      console.error('调用云函数 getLeaderboard 失败:', err);
      this.setData({
        loading: false,
        error: true,
        errorMessage: '网络错误或服务器问题'
      });
      wx.showToast({ title: '网络错误，请稍后再试', icon: 'none' });
    } finally {
      if (isRefresh) {
        wx.stopPullDownRefresh(); // 停止下拉刷新
      }
    }
  },

  // 如果需要，可以在页面上添加一个按钮，点击后重新获取用户信息
  // 仅在用户明确点击时调用 wx.getUserProfile
  reGetUserInfo: function() {
    wx.getUserProfile({
      desc: '用于更新排行榜上的个人信息',
      success: (resProfile) => {
        console.log('用户重新授权信息:', resProfile.userInfo);
        this.setData({
          'myInfo.nickName': resProfile.userInfo.nickName,
          'myInfo.avatarUrl': resProfile.userInfo.avatarUrl
        });
        wx.setStorageSync('userInfo', resProfile.userInfo); // 缓存最新信息
        wx.showToast({ title: '用户信息已更新', icon: 'success' });
        this.getLeaderboardData(true); // 更新用户信息后刷新排行榜
      },
      fail: (err) => {
        console.error('用户拒绝重新授权', err);
        wx.showToast({
          title: '授权失败，个人信息无法更新',
          icon: 'none'
        });
      }
    });
  }
});
