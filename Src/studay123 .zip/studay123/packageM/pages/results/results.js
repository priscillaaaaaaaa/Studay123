// pages/results/results.js
var app = getApp();
const db = wx.cloud.database(); // <<<<<<<<<<<<<<<< 新增：获取云数据库实例

Page({
  data: {
    totalScore: null, // 分数
    wrongList: [], // 错误的题数-乱序 (存储的是 math1 页面中 shuffleIndex 对应的索引)
    wrongListSort: [], // 错误的题数-正序 (存储的是 math1 页面中 questionList 对应的原始索引)
    chooseValue: [], // 选择的答案 (用户输入的答案序列)
    remark: ["好极了！你很厉害哦", "哎哟不错哦", "别灰心，继续努力哦！"], // 评语
    modalShow: false, // 控制查看错题弹窗的显示
    questionList: [], // <<<<<<<<<<<<<<<< 用于存储从云数据库获取的完整题库数据
    testId: '' // 课程ID (例如 'math1', 'math2')
  },

  onLoad: function (options) {
    console.log("Results page options:", options);
    // 动态设置导航条标题
    // 可以根据 testId 再次设置更友好的标题，或者直接显示 options.testId
    let navigationTitle = options.testId === 'math1' ? '一年级结果' :
                          options.testId === 'math2' ? '二年级结果' :
                          options.testId === 'math3' ? '三年级结果' : options.testId;
    wx.setNavigationBarTitle({ title: navigationTitle }); 
    
    // 解析从上一个页面传递过来的JSON字符串数据
    let wrongList = JSON.parse(options.wrongList);
    let wrongListSort = JSON.parse(options.wrongListSort);
    let chooseValue = JSON.parse(options.chooseValue);

    // 设置页面基础数据
    this.setData({
      totalScore: options.totalScore != "" ? options.totalScore : "222", // 如果分数为空，给个默认值
      wrongList: wrongList,
      wrongListSort: wrongListSort,
      chooseValue: chooseValue,
      testId: options.testId  // 保存课程ID
    });
    console.log("用户选择的答案序列:", this.data.chooseValue);

    // <<<<<<<<<<<<<<<< 以下是修改的部分：从云数据库获取题库 >>>>>>>>>>>>>>>>>>
    let targetGrade = '';
    switch (options.testId) {
      case 'math1':
        targetGrade = '一';
        break;
      case 'math2':
        targetGrade = '二';
        break;
      case 'math3':
        targetGrade = '三';
        break;
      default:
        targetGrade = ''; // 如果 testId 不匹配，设置为空
        break;
    }

    if (!targetGrade) {
      console.error("Results page received invalid testId:", options.testId);
      wx.showToast({
        title: '无法加载错题详情',
        icon: 'none',
        duration: 2000
      });
      return; // 终止执行
    }

    wx.showLoading({
      title: '加载错题信息...',
      mask: true
    });

    db.collection('questions') // 假设你的题目**名为 'questions'
      .where({
        grade: targetGrade // <<<<<<<<<<<<<<<< 根据 grade 字段筛选题目
      })
      .get()
      .then(res => {
        wx.hideLoading(); // 隐藏加载提示
        console.log(`从云数据库获取 ${targetGrade} 年级题库成功:`, res.data);

        if (res.data && res.data.length > 0) {
          this.setData({
            questionList: res.data // 将获取到的完整题库数据设置到 data 中
          });
          // 此时 questionList 包含了所有该年级的题目，可以在查看错题功能中使用
        } else {
          console.warn(`未找到 ${targetGrade} 年级题库数据。`);
          wx.showToast({
            title: '未找到对应题库',
            icon: 'none',
            duration: 2000
          });
        }
      })
      .catch(err => {
        wx.hideLoading(); // 隐藏加载提示
        console.error('从云数据库获取题库失败:', err);
        wx.showToast({
          title: '加载题库失败',
          icon: 'none',
          duration: 2000
        });
      });
    // <<<<<<<<<<<<<<<< 结束修改的部分 >>>>>>>>>>>>>>>>>>
  },

  // 查看错题
  toView: function(){
    // 显示弹窗
    this.setData({
      modalShow: true
    });
    // 在这里，你可以根据 this.data.wrongList 和 this.data.questionList
    // 来组合出需要显示在弹窗中的错题详情。
    // 例如，可以创建一个新的数组，包含每道错题的题目、正确答案和用户答案。
    // let detailedWrongQuestions = this.data.wrongList.map(wrongIndex => {
    //   const originalIndex = this.data.wrongListSort[wrongIndex]; // 假设 wrongList 存储的是 shuffleIndex 的索引
    //   const question = this.data.questionList[originalIndex];
    //   const userAnswer = this.data.chooseValue[wrongIndex];
    //   return {
    //     question: question.question,
    //     correctAnswer: question.answer,
    //     userAnswer: userAnswer
    //   };
    // });
    // this.setData({ detailedWrongQuestions });
  },

  // 关闭错题弹窗
  hideModal: function() { // <<<<<<<<<<<<<<<< 假设你有这个方法来关闭弹窗
    this.setData({
      modalShow: false
    });
  },

  // 返回首页
  toIndex: function(){
    wx.reLaunch({
      url: '/packageM/pages/mathhome/mathhome' // 确保路径正确
    });
  }
});
