Page({
    data: {
      favoriteWords: [],
    },
  
    onLoad: function() {
      this.loadFavoriteWords();
    },
  
    // 加载收藏的题目列表
    loadFavoriteWords: function() {
      const favoriteWords = wx.getStorageSync('favoriteWords') || [];
      this.setData({ favoriteWords });
    },
  
    // 删除题目
    deleteWord: function(event) {
      const index = event.currentTarget.dataset.index;
      const updatedFavorites = this.data.favoriteWords;
      updatedFavorites.splice(index, 1);
  
      // 更新数据并同步到本地存储
      this.setData({ favoriteWords: updatedFavorites });
      wx.setStorageSync('favoriteWords', updatedFavorites);
      wx.showToast({
        title: '已移出收藏',
        icon: 'none'
      });
    }
  });
   