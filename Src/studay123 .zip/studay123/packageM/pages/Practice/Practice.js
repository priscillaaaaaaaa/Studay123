// packageM/pages/Practice/Practice.js

const db = wx.cloud.database(); // <<<<<<<<<<<<<<<< 新增：获取云数据库实例

Page({
  data: {
    wrongQuestionGradeFilter: '', // 从上一页传入的错题 grade
    currentQuestionIndex: 0,  // 当前题目的索引
    currentQuestion: null,    // 当前显示的题目对象
    userInputValue: '',       // 用户输入的答案
    score: 0,                 // 正确答题数 (这个变量在你的逻辑中似乎没有被实际使用，主要用 correctAnswersCount)
    isPracticeComplete: false,// 练习是否完成
    totalQuestions: 3,        // 总共练习的题目数量 (可以根据需求调整)
    isAnswerSubmitted: false, // 答案是否已提交，用于禁用输入和按钮
    inputFocus: false,        // 控制输入框焦点
    noQuestionsFound: false,   // 是否没有找到匹配的题目
    correctAnswersCount: 0,  //记录用户连续或累计答对的题目数量
    practiceQuestions: []     // 当前练习会话的题目列表
  },

  onLoad: function(options) {
    // 1. 获取从上一页传入的 grade 参数
    const grade = options.grade || ''; // 默认值为空字符串
    this.setData({
      wrongQuestionGradeFilter: grade,
    });

    if (!grade) {
      console.error("错误：未指定练习年级！");
      wx.showToast({
        title: '请选择练习年级',
        icon: 'none'
      });
      this.setData({ noQuestionsFound: true, isPracticeComplete: true });
      return;
    }

    // 2. 从云数据库获取题目并初始化练习
    this.fetchQuestionsFromCloud(grade);
  },

  /**
   * <<<<<<<<<<<<<<<< 新增方法：从云数据库获取题目 >>>>>>>>>>>>>>>>>>
   */
  fetchQuestionsFromCloud: function(grade) {
    wx.showLoading({
      title: '加载题目中...',
      mask: true
    });

    db.collection('questions') // 假设你的题目集合名为 'questions'
      .where({
        grade: grade // 根据 grade 字段筛选题目
      })
      .get()
      .then(res => {
        wx.hideLoading();
        console.log(`从云数据库获取 ${grade} 年级题库成功:`, res.data);

        if (res.data && res.data.length > 0) {
          this.setupPracticeQuestions(res.data); // 将获取到的数据传递给设置练习题目函数
        } else {
          console.warn(`未找到 ${grade} 年级题库数据。`);
          wx.showToast({
            title: '未找到对应题库',
            icon: 'none',
            duration: 2000
          });
          this.setData({ noQuestionsFound: true, isPracticeComplete: true });
        }
      })
      .catch(err => {
        wx.hideLoading();
        console.error('从云数据库获取题库失败:', err);
        wx.showToast({
          title: '加载题库失败',
          icon: 'none',
          duration: 2000
        });
        this.setData({ noQuestionsFound: true, isPracticeComplete: true });
      });
  },

  /**
   * <<<<<<<<<<<<<<<< 修改方法：初始化练习题目 >>>>>>>>>>>>>>>>>>
   * @param {Array} questionsForGrade - 从云数据库获取到的特定年级的题目数组
   */
  setupPracticeQuestions: function(questionsForGrade) {
    const { totalQuestions } = this.data;
    
    if (questionsForGrade.length === 0) {
      this.setData({
        noQuestionsFound: true,
        isPracticeComplete: true
      });
      return;
    }

    // 打乱题目顺序
    const shuffledQuestions = this.shuffleArray(questionsForGrade);
    // 取前 totalQuestions 题进行练习
    const practiceQuestions = shuffledQuestions.slice(0, totalQuestions);

    if (practiceQuestions.length === 0) {
      this.setData({
        noQuestionsFound: true,
        isPracticeComplete: true
      });
      return;
    }

    this.setData({
      practiceQuestions: practiceQuestions,
      currentQuestionIndex: 0,
      currentQuestion: practiceQuestions[0],
      userInputValue: '',
      // feedbackMessage: '', // 移除
      // feedbackClass: '',   // 移除
      score: 0,            // 重置分数
      isPracticeComplete: false,
      isAnswerSubmitted: false,
      inputFocus: true,    // 自动聚焦输入框
      noQuestionsFound: false,
      correctAnswersCount: 0 // 重置连续答对计数
    });
  },

  // 打乱数组顺序的辅助函数
  shuffleArray: function(array) {
    const newArray = [...array]; // <<<<<<<<<<<<<<<< 优化：创建副本，避免修改原始数组
    for (let i = newArray.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [newArray[i], newArray[j]] = [newArray[j], newArray[i]];
    }
    return newArray;
  },

  handleInput: function(e) {
    this.setData({
      userInputValue: e.detail.value
    });
  },

  submitAnswer: function() {
    // <<<<<<<<<<<<<<<< 修正：使用 userInputValue 而不是 userAnswer
    const { currentQuestionIndex, practiceQuestions, userInputValue, correctAnswersCount } = this.data;
    const currentQuestion = practiceQuestions[currentQuestionIndex];
  
    if (!currentQuestion) {
      console.error("当前题目为空，无法提交答案。");
      return;
    }

    // 验证正误 (确保类型一致性，例如 '1' == 1)
    const isCorrect = String(userInputValue) === String(currentQuestion.answer);
 
    let newCorrectAnswersCount = correctAnswersCount;
    if (isCorrect) {
      newCorrectAnswersCount++; // 答对则计数器加一
      wx.showToast({
        title: '回答正确！',
        icon: 'success',
        duration: 1000
      });
    } else {
      newCorrectAnswersCount = 0; // 答错则计数器清零 (如果你想实现连续答对3题)
      wx.showToast({
        title: `回答错误！正确答案是 ${currentQuestion.answer}`, // <<<<<<<<<<<<<<<< 提示正确答案
        icon: 'none',
        duration: 2000
      });
    }
  
    this.setData({
      isAnswerSubmitted: true, // 标记已提交
      correctAnswersCount: newCorrectAnswersCount, // 更新正确答案计数
    });
  
    // 延迟一段时间后检查是否继续或结束
    setTimeout(() => {
      this.checkPracticeStatus();
    }, 1500); // 1.5秒后检查状态，给用户看提示的时间
  },

  checkPracticeStatus: function() {
    const { correctAnswersCount, practiceQuestions, currentQuestionIndex, wrongQuestionGradeFilter } = this.data;
    const requiredCorrectAnswers = 3; // 达到这个数量就结束练习
  
    // 检查是否已经答对足够多的题目
    if (correctAnswersCount >= requiredCorrectAnswers) {
      wx.showModal({
        title: '恭喜！',
        content: `你已经连续答对${requiredCorrectAnswers}道题了，练习结束！`,
        showCancel: false,
        confirmText: '返回',
        success: () => {
          wx.navigateBack(); // 或者跳转到结果页
        }
      });
      return; // 结束练习
    }
  
    // 检查是否还有题目可做
    const nextIndex = currentQuestionIndex + 1;
    if (nextIndex < practiceQuestions.length) {
      this.setData({
        currentQuestionIndex: nextIndex,
        currentQuestion: practiceQuestions[nextIndex],
        userInputValue: '',       // 清空输入
        isAnswerSubmitted: false,
        inputFocus: false         // 先取消焦点
      });
      // 确保下一题渲染后再重新聚焦
      setTimeout(() => {
        this.setData({ inputFocus: true });
      }, 100);
    } else {
      // 所有题目都做完了，但还没答对足够数量
      wx.showModal({
        title: '练习结束',
        content: `所有题目都已完成，但你还没有连续答对${requiredCorrectAnswers}道题。是否重新开始？`,
        confirmText: '重新开始',
        cancelText: '返回',
        success: (res) => {
          if (res.confirm) {
            // <<<<<<<<<<<<<<<< 重新开始练习：重新从云数据库获取题目
            this.fetchQuestionsFromCloud(wrongQuestionGradeFilter);
          } else {
            wx.navigateBack(); // 返回上一页
          }
        }
      });
    }
  },

  goToPreviousPage: function() {
    wx.navigateBack({
      delta: 1 // 返回上一页
    });
  }
});
