var app = getApp();
Page({
  data: {
    wrongques: [],            // 当前错题列表
    currentIndex: 0,          // 当前题索引
    resultInput: '',          // 当前输入的答案
    overallCorrectCount: 0,   // 记录真正“已改正”的错题数（满足三题达标时才+1）
    currentWord: {},          // 当前题目
    focusInput: true
  },

  onLoad() {
    this.loadWrongques();
  },

  // 从缓存读取错题集
  loadWrongques() {
    const wrongques = wx.getStorageSync('wrongques') || [];
    if (wrongques.length === 0) {
      wx.showToast({ title: '暂无错题', icon: 'none', duration: 1500 }); // 保持1.5s，因为后面有navigateBack
      // 如果没有错题，直接返回上一页或跳转到首页
      setTimeout(() => {
        wx.navigateBack({ delta: 1 }); // 返回上一页
      }, 1500);
      return;
    }

    // 生成唯一键 & 初始化状态
    wrongques.forEach(q => {
      q.uniqueNo = `${q.grade}-${q.no}`;
    });

    this.setData({
      wrongques,
      currentWord: wrongques[0],
      currentIndex: 0,
      resultInput: '',
      overallCorrectCount: 0,
      focusInput: true // 确保加载新题目时输入框自动聚焦
    });
  },

  // 输入答案
  resultInputChange(e) {
    this.setData({ resultInput: e.detail.value });
  },

  // 提交答案
  submitAnswer() {
    let {
      wrongques,
      currentIndex,
      resultInput,
      overallCorrectCount
    } = this.data;

    if (!resultInput || resultInput.trim() === '') {
      wx.showToast({ title: '请输入答案', icon: 'none', duration: 1000 }); // 缩短提示时间
      return;
    }

    if (wrongques.length === 0) {
      wx.showToast({ title: '没有错题可练习了', icon: 'none', duration: 1000 }); // 缩短提示时间
      return;
    }

    const question = wrongques[currentIndex];
    const trueAnswer = (question.answer || '').toString().trim();
    const userAnswer = resultInput.toString().trim();

    // 答错 → 停留并清空输入
    if (userAnswer !== trueAnswer) {
      wx.showToast({ title: '答错了，请重做！', icon: 'none', duration: 1000 }); // 缩短提示时间
      this.setData({
        resultInput: '', // <<<<<<<<<<<<<<<< 答错后清空输入框
        focusInput: true // 确保输入框保持焦点
      });
      return;
    }

    // ✅ 答对逻辑
    wx.showToast({ title: '答对啦！', icon: 'success', duration: 1000 }); // 缩短提示时间

    // 答对后，从错题集中移除
    overallCorrectCount += 1;
    wrongques.splice(currentIndex, 1); // 移除当前答对的题目

    wx.setStorageSync('wrongques', wrongques); // 立即更新缓存

    // 检查是否所有错题都已完成
    if (wrongques.length === 0) {
      wx.showModal({
        title: '恭喜！',
        content: `你真棒！全部错题都掌握啦！\n已改正 ${overallCorrectCount} 道题。`,
        showCancel: false,
        confirmText: '确定',
        success: () => {
          setTimeout(() => {
            wx.navigateBack({ delta: 1 }); // 返回上一页
          }, 100); // 稍微延迟一下，确保弹窗关闭后才返回
        }
      });
      return; // 结束函数执行
    }

    // 还有错题，进入下一题
    const nextIndex = currentIndex >= wrongques.length ? 0 : currentIndex; // 如果当前索引超出新数组长度，则回到第一题
    this.setData({
      wrongques: wrongques, // 更新错题列表
      currentIndex: nextIndex,
      currentWord: wrongques[nextIndex] || {}, // 更新当前题目
      resultInput: '', // <<<<<<<<<<<<<<<< 答对后清空输入框 (已存在)
      overallCorrectCount: overallCorrectCount, // 更新已改正计数
      focusInput: true // 确保输入框自动聚焦
    });
  },

  //跳转同类题
  getCurrentWrongQuestionGrade: function() {
    const { currentWord } = this.data;
    if (currentWord && currentWord.grade) {
      return currentWord.grade;
    } else {
      console.warn('当前没有错题或错题缺少 grade 属性。');
      return null;
    }
  },
  backToHome: function() {
    wx.navigateBack(); 
  },
  // 跳转到 Practice 页面，并传入当前错题的 grade
  goToPagePractice: function() {
    const gradeToPass = this.getCurrentWrongQuestionGrade(); // 调用我们新写的函数

    if (gradeToPass) {
      wx.navigateTo({
        url: `/packageM/pages/Practice/Practice?grade=${gradeToPass}`,
        success: function() {
          console.log(`成功跳转到 Practice 页面，并传递 grade: ${gradeToPass}`);
        },
        fail: function(err) {
          console.error('跳转失败', err);
        }
      });
    } else {
      wx.showToast({
        title: '无法获取当前题目年级',
        icon: 'none',
        duration: 1500 // 非关键提示，可以稍长
      });
    }
  }
});
