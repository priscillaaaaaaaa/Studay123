// pages/math1/math1.js
var app = getApp();
const db = wx.cloud.database(); // 获取云数据库实例

Page({
  data: {
    index: 0, // 当前题目序号
    chooseValue: [], // 用户作答记录
    totalScore: 100, // 初始总分
    wrong: 0, // 错题数量
    wrongList: [], // 错题的随机索引
    wrongListSort: [], // 错题的原始索引
    num: 0, // 题目数量
    result11: null, // 当前输入的答案
    focusInput: false,
    currentWord: {}, // 当前显示的题目
    favoriteWords: [], // 收藏的题目
    wrongques: [], // 错题本
    isFavorited: false,
    questionList: [], // 题目数组
    testId: '', // 当前课程id，如 math1
    shuffleIndex: [], // 随机索引数组
    userInfo: null // 用户信息
  },

  // 页面加载
  async onLoad(options) {
    console.log("onLoad options:", options);
    wx.showLoading({ title: '加载题库中...', mask: true });

    const favoriteWords = wx.getStorageSync('favoriteWords') || [];
    const wrongques = wx.getStorageSync('wrongques') || [];
    this.setData({
      favoriteWords,
      wrongques,
      result11: '',
      testId: options.testId
    });

    this.checkAndGetUserInfo(); // 获取用户信息

    // 根据 testId 决定年级
    let targetGrade = '';
    let navigationTitle = '默认标题';
    switch (options.testId) {
      case 'math1': targetGrade = '一'; navigationTitle = '一年级题目'; break;
      case 'math2': targetGrade = '二'; navigationTitle = '二年级题目'; break;
      case 'math3': targetGrade = '三'; navigationTitle = '三年级题目'; break;
      default: targetGrade = ''; navigationTitle = '未知年级题目';
    }

    wx.setNavigationBarTitle({ title: navigationTitle });

    if (!targetGrade) {
      wx.hideLoading();
      wx.showToast({ title: '无效的题目类型', icon: 'none' });
      setTimeout(() => wx.navigateBack(), 2000);
      return;
    }

    // 调用云端随机选题
    await this.loadRandomQuestions(targetGrade, options.number);
  },

  /**
   * ☁️ 从云数据库随机抽题
   */
  loadRandomQuestions: async function (targetGrade, number) {
    try {
      const questionsCollection = db.collection('questions').where({ grade: targetGrade });
      const countRes = await questionsCollection.count();
      const total = countRes.total;

      if (total === 0) {
        wx.hideLoading();
        wx.showToast({
          title: `未找到 ${targetGrade} 年级题目`,
          icon: 'none'
        });
        setTimeout(() => wx.navigateBack(), 2000);
        return;
      }

      let requestedNum = number ? parseInt(number) : total;
      requestedNum = Math.min(requestedNum, total);

      if (requestedNum > total) {
        wx.showToast({
          title: `题目数量不足，仅显示${total}道题`,
          icon: 'none'
        });
      }

      // 生成不重复随机索引
      const randomIndexes = [];
      while (randomIndexes.length < requestedNum) {
        const r = Math.floor(Math.random() * total);
        if (!randomIndexes.includes(r)) randomIndexes.push(r);
      }

      // 随机抽题
      const randomQuestions = [];
      for (let i = 0; i < randomIndexes.length; i++) {
        const res = await questionsCollection.skip(randomIndexes[i]).limit(1).get();
        if (res.data && res.data.length > 0) randomQuestions.push(res.data[0]);
      }

      wx.hideLoading();
      console.log(`✅ 成功随机抽取 ${randomQuestions.length} 道题`, randomQuestions);

      this.setData({
        questionList: randomQuestions,
        num: randomQuestions.length,
        shuffleIndex: this.generateArray(0, randomQuestions.length - 1)
      });

      this.showWord();
    } catch (err) {
      wx.hideLoading();
      console.error('随机抽题失败：', err);
      wx.showToast({ title: '加载题库失败', icon: 'none' });
      setTimeout(() => wx.navigateBack(), 2000);
    }
  },

  // 检查用户信息
  checkAndGetUserInfo: async function () {
    try {
      let userInfo = wx.getStorageSync('userInfo') || null;
      let openid = wx.getStorageSync('openid');

      if (!openid) {
        const res = await wx.cloud.callFunction({ name: 'login' });
        openid = res?.result?.openid;
        if (openid) wx.setStorageSync('openid', openid);
      }

      if (openid) {
        try {
          const res = await db.collection('user_scores').doc(openid).get();
          if (res?.data) {
            userInfo = res.data;
            wx.setStorageSync('userInfo', userInfo);
            wx.setStorageSync('nickname', userInfo.nickName || '');
            wx.setStorageSync('avatarUrl', userInfo.avatarUrl || '');
            console.log('✅ 已从云端同步用户信息：', userInfo);
          }
        } catch (err) {
          console.warn('从云端获取用户信息失败，使用缓存', err);
        }
      }

      this.setData({ userInfo });
      return userInfo;
    } catch (err) {
      console.error('checkAndGetUserInfo 出错：', err);
      wx.showToast({ title: '获取用户信息失败', icon: 'none' });
      return null;
    }
  },

  // 显示当前题
  showWord: function () {
    if (!this.data.questionList || this.data.questionList.length === 0) return;

    const word = this.data.questionList[this.data.shuffleIndex[this.data.index]];
    this.setData({ currentWord: word, isFavorited: false });
    this.checkIfFavorited();
  },

  // 判断是否已收藏
  checkIfFavorited: function () {
    const { currentWord, favoriteWords } = this.data;
    if (!currentWord || !favoriteWords) return;
    const isFavorited = favoriteWords.some(word => word.no === currentWord.no);
    this.setData({ isFavorited });
  },

  // 收藏/取消收藏
  toggleFavorite: function () {
    const { currentWord, favoriteWords, isFavorited } = this.data;
    if (!currentWord || !currentWord.no) return;

    if (isFavorited) {
      const updated = favoriteWords.filter(w => w.no !== currentWord.no);
      this.setData({ favoriteWords: updated, isFavorited: false });
      wx.setStorageSync('favoriteWords', updated);
      wx.showToast({ title: '已取消收藏', icon: 'none' });
    } else {
      favoriteWords.push(currentWord);
      this.setData({ favoriteWords, isFavorited: true });
      wx.setStorageSync('favoriteWords', favoriteWords);
      wx.showToast({ title: '已收藏', icon: 'success' });
    }
  },

  // 用户输入答案
  result11: function (e) {
    this.data.chooseValue[this.data.index] = e.detail.value;
    this.setData({ result11: e.detail.value });
  },

  // 下一题 / 提交
  nextSubmit: async function () {
    if (!this.data.result11 || this.data.result11.toString().trim() === '') {
      wx.showToast({ title: '请输入答案', icon: 'none' });
      return;
    }

    await this.chooseError();

    if (this.data.index < this.data.shuffleIndex.length - 1) {
      this.setData({
        index: this.data.index + 1,
        result11: '',
        focusInput: true
      });
      this.showWord();
    } else {
      let wrongList = JSON.stringify(this.data.wrongList);
      let wrongListSort = JSON.stringify(this.data.wrongListSort);
      let chooseValue = JSON.stringify(this.data.chooseValue);

      wx.navigateTo({
        url: `/packageM/pages/results/results?totalScore=${this.data.totalScore}&wrongList=${wrongList}&chooseValue=${chooseValue}&wrongListSort=${wrongListSort}&testId=${this.data.testId}`
      });

      var logs = wx.getStorageSync('logs') || [];
      logs.unshift({
        date: Date.now(),
        testId: this.data.testId,
        score: this.data.totalScore,
        number: this.data.num
      });
      wx.setStorageSync('logs', logs);
    }
  },

  // 判断对错
  chooseError: async function () {
    const trueValue = this.data.currentWord.answer;
    const chooseVal = this.data.result11;

    if (chooseVal != trueValue) {
      this.data.wrong++;
      this.data.wrongListSort.push(this.data.index);
      this.data.wrongList.push(this.data.shuffleIndex[this.data.index]);
      this.setData({
        totalScore: this.data.totalScore - (100 / this.data.num),
        result11: ''
      });

      const { currentWord, wrongques } = this.data;
      const isExist = wrongques.some(item => item.no === currentWord.no);
      if (!isExist) {
        const wrongItem = { ...currentWord, userAnswer: chooseVal };
        wrongques.push(wrongItem);
        this.setData({ wrongques });
        wx.setStorageSync('wrongques', wrongques);
      }
    } else {
      await this.updateUserScore();
    }
  },

  // 生成连续数组
  generateArray: function (start, end) {
    return Array.from(new Array(end + 1).keys()).slice(start);
  },

  // 更新排行榜分数
  updateUserScore: async function () {
    try {
      let userInfo = this.data.userInfo;
      if (!userInfo || !userInfo.nickName || !userInfo.avatarUrl) {
        userInfo = await this.checkAndGetUserInfo();
      }

      if (userInfo && userInfo.nickName && userInfo.avatarUrl) {
        const res = await wx.cloud.callFunction({
          name: 'updateUserScore',
          data: {
            correctCountIncrement: 1,
            nickName: userInfo.nickName,
            avatarUrl: userInfo.avatarUrl
          }
        });
        console.log('✅ 更新用户成绩成功:', res.result);
      }
    } catch (err) {
      console.error('更新用户成绩失败:', err);
      wx.showToast({ title: '排行榜更新失败', icon: 'none' });
    }
  },

  // 退出答题
  outTest: function () {
    wx.showModal({
      title: '提示',
      content: '确定要退出答题吗？',
      success(res) {
        if (res.confirm) {
          wx.reLaunch({ url: '/packageM/pages/mathhome/mathhome' });
        }
      }
    });
  }
});
